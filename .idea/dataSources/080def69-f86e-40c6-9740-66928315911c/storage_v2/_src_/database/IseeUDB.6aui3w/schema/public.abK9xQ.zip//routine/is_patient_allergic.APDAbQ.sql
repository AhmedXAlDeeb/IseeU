create function is_patient_allergic(encounter integer, drug_name character varying) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN NOT EXISTS (SELECT 1 FROM AllergicDrugs WHERE PatientID = encounter AND DrugName = drug_name);
END;
$$;

alter function is_patient_allergic(integer, varchar) owner to "IseeUDB_owner";

