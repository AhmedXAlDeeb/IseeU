create function is_patient_allergic(patient character varying, drug_name character varying) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN NOT EXISTS (SELECT 1 FROM AllergicDrugs WHERE PatientID = patient AND DrugName = drug_name);
END;
$$;

alter function is_patient_allergic(varchar, varchar) owner to "IseeUDB_owner";

