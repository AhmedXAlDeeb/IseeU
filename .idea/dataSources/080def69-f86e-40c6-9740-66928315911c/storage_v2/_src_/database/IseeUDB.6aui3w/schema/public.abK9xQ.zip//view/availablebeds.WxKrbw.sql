create view availablebeds(bedid) as
SELECT bedid
FROM bed b
WHERE NOT (bedid IN (SELECT p.bedid
                     FROM encounters p
                     WHERE p.dischargedatetime IS NOT NULL));

alter table availablebeds
    owner to "IseeUDB_owner";

