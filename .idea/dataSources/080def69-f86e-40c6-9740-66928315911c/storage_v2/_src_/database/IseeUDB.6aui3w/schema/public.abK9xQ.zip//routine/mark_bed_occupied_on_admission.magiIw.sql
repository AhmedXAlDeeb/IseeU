create function mark_bed_occupied_on_admission() returns trigger
    language plpgsql
as
$$
        BEGIN
          UPDATE Bed
          SET IsOccupied = TRUE
          WHERE BedID = NEW.bedID;

          IF NEW.bedID IS NOT NULL THEN  -- Check if bed was assigned
            RETURN NEW;
          ELSE
            RAISE EXCEPTION 'No available bed found for patient.';
          END IF;
        END;
    $$;

alter function mark_bed_occupied_on_admission() owner to "IseeUDB_owner";

