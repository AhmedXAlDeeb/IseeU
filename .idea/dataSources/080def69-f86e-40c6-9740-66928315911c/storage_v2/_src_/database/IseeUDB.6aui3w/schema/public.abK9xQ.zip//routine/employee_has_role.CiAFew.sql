create function employee_has_role(employee_id integer, role_name character varying) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN EXISTS (SELECT 1 FROM Employee WHERE EmployeeID = employee_id AND Role = role_name);
END;
$$;

alter function employee_has_role(integer, varchar) owner to "IseeUDB_owner";

