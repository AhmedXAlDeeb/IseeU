create function is_bed_available(bed_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN EXISTS (SELECT 1 FROM AvailableBeds WHERE bedID = bed_id);
END;
$$;

alter function is_bed_available(integer) owner to "IseeUDB_owner";

