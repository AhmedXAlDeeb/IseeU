create function mark_bed_available_on_discharge() returns trigger
    language plpgsql
as
$$
        BEGIN
          UPDATE Bed
          SET IsOccupied = FALSE
          WHERE BedID = OLD.bedID;

          RETURN NEW;
        END;
    $$;

alter function mark_bed_available_on_discharge() owner to "IseeUDB_owner";

